#define Dly4SNAus 29
#define Dly4Z80us 29
#define Dly4SCRus 29
#define Dly4SINGLEus 35
#define Dly4ROMSETus 29
#define Dly4NIBBLEus 9
#define Dly4DIRLISTus 29 // Depends on number of directory entries. Watch out
#define DlyANSWERus 29
#define DlyLAUNCHms 10
#define DlyROMSETms 5
#define DlyTAPms 5
